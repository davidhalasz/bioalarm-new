<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KapcsolatController extends Controller
{
    //
}
