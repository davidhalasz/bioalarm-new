<?php return array (
  'contact' => 'App\\Http\\Livewire\\Contact',
  'edit-article' => 'App\\Http\\Livewire\\EditArticle',
  'form-hir' => 'App\\Http\\Livewire\\FormHir',
  'form-kep' => 'App\\Http\\Livewire\\FormKep',
  'show-hir' => 'App\\Http\\Livewire\\ShowHir',
  'show-kep' => 'App\\Http\\Livewire\\ShowKep',
);