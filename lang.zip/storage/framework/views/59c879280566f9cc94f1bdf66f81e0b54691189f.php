<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <h1 class="p-6 text-center text-2xl">Új cikk hozzáadása</h1>
                <div class="card-body p-6">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form-hir')->html();
} elseif ($_instance->childHasBeenRendered('poPArH9')) {
    $componentId = $_instance->getRenderedChildComponentId('poPArH9');
    $componentTag = $_instance->getRenderedChildComponentTagName('poPArH9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('poPArH9');
} else {
    $response = \Livewire\Livewire::mount('form-hir');
    $html = $response->html();
    $_instance->logRenderedChild('poPArH9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-hir')->html();
} elseif ($_instance->childHasBeenRendered('MQ3aVmy')) {
    $componentId = $_instance->getRenderedChildComponentId('MQ3aVmy');
    $componentTag = $_instance->getRenderedChildComponentTagName('MQ3aVmy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MQ3aVmy');
} else {
    $response = \Livewire\Livewire::mount('show-hir');
    $html = $response->html();
    $_instance->logRenderedChild('MQ3aVmy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
                  <?php echo \Livewire\Livewire::scripts(); ?>

                  
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\projekt4\bioalarm-new\resources\views/vendor/jetstream/hirek-feltoltese.blade.php ENDPATH**/ ?>