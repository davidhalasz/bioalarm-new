<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <h1 class="p-6 text-center text-2xl">Képek hozzáadása</h1>
                <div class="card-body p-6">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form-kep')->html();
} elseif ($_instance->childHasBeenRendered('yii4TIG')) {
    $componentId = $_instance->getRenderedChildComponentId('yii4TIG');
    $componentTag = $_instance->getRenderedChildComponentTagName('yii4TIG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yii4TIG');
} else {
    $response = \Livewire\Livewire::mount('form-kep');
    $html = $response->html();
    $_instance->logRenderedChild('yii4TIG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-kep')->html();
} elseif ($_instance->childHasBeenRendered('NjdVqxs')) {
    $componentId = $_instance->getRenderedChildComponentId('NjdVqxs');
    $componentTag = $_instance->getRenderedChildComponentTagName('NjdVqxs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NjdVqxs');
} else {
    $response = \Livewire\Livewire::mount('show-kep');
    $html = $response->html();
    $_instance->logRenderedChild('NjdVqxs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                   
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\projekt4\bioalarm-new\resources\views/vendor/jetstream/kepek-feltoltese.blade.php ENDPATH**/ ?>