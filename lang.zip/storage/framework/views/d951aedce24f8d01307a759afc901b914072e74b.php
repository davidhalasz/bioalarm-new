<div>
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success bg-emerald-400 border border-emerald-800 text-white 
        rounded-lg focus:ring-blue-500 focus:border-blue-500 block mx-auto p-2.5 w-1/2 text-center font-bold mb-6">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <form>
        <div class="grid grid-cols-4 gap-2 add-input mb-4">
            <div class="form-group my-auto">
                <label class="custom-file-label" for="chooseFile.0">
                    <input type="file" name="filename.0" class="custom-file-input" id="chooseFile.0"
                        wire:model="filepath.0">
                    <?php $__errorArgs = ['filepath.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <br /><span class="text-red-800 error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>
        </div>

        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="grid grid-cols-4 gap-2 add-input mb-4">
                <div class="form-group my-auto">
                    <label class="custom-file-label" for="chooseFile.<?php echo e($value); ?>">
                        <input type="file" name="filename.<?php echo e($value); ?>" class="custom-file-input" id="chooseFile.<?php echo e($value); ?>"
                        wire:model="filepath.<?php echo e($value); ?>">
                        <?php $__errorArgs = ['filepath.' . $value];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <br /><span class="text-red-800 error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                </div>
                <div class="ml-6">
                    <button class="px-4 text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 focus:outline-none dark:focus:ring-red-800"
                        wire:click.prevent="remove(<?php echo e($key); ?>)">Törlés</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-2">
                <button class="px-4 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"
                    wire:click.prevent="add(<?php echo e($i); ?>)">Új kép hozzáadása</button>
            </div>
            <div class="col-md-12 text-right">
                <button type="button" wire:click.prevent="submit()" class="px-4 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Feltöltés</button>
            </div>
        </div>
    </form>
</div><?php /**PATH D:\projekt4\bioalarm-new\resources\views/livewire/form-kep.blade.php ENDPATH**/ ?>