<form wire:submit.prevent="submit(<?php echo e($cikk->id); ?>)">
    <div class="form-group mb-6 text-gray-900">
        <label for="title" class="block mb-2 text-sm font-medium">Cím</label>
        <input type="text" id="title" wire:model="title" value="<?php echo e($cikk->title); ?>"
            class="bg-gray-50 border border-gray-300 text-black 
            rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group mb-6">
        <label for="body" class="block mb-2 text-sm font-medium">Szöveg</label>
        <div>
            <trix-editor wire:model.lazy="body" wire:ignore x-data @trix-blur="$dispatch('change', $event.target.value)">
                
            </trix-editor>
        </div>

        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="w-full">
        <button type="submit"
            class="px-4 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800">Küldés</button>
    </div>
</form>
<?php /**PATH D:\projekt4\bioalarm-new\resources\views/livewire/edit-article.blade.php ENDPATH**/ ?>